#pragma once

#include "CommonIncludes.h"
#include <time.h>
#include <unordered_map>
#define FOREGROUND_WHITE		    (FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN)
#define FOREGROUND_YELLOW       	(FOREGROUND_RED | FOREGROUND_GREEN)
#define FOREGROUND_CYAN		        (FOREGROUND_BLUE | FOREGROUND_GREEN)
#define FOREGROUND_MAGENTA	        (FOREGROUND_RED | FOREGROUND_BLUE)
#define FOREGROUND_BLACK		    0

#define FOREGROUND_INTENSE_RED		(FOREGROUND_RED | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_GREEN	(FOREGROUND_GREEN | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_BLUE		(FOREGROUND_BLUE | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_WHITE	(FOREGROUND_WHITE | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_YELLOW	(FOREGROUND_YELLOW | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_CYAN		(FOREGROUND_CYAN | FOREGROUND_INTENSITY)
#define FOREGROUND_INTENSE_MAGENTA	(FOREGROUND_MAGENTA | FOREGROUND_INTENSITY)

namespace Utilities
{
	void OpenConsole(std::string Title);
	void CloseConsole();
	void Log(const char *fmt, ...);

	void EnableLogFile(std::string filename);

	void SetConsoleColor(WORD color);  

	std::string GetTimeString();
	
	namespace Memory
	{

		DWORD WaitOnModuleHandle(std::string moduleName);

		void * capture_interface(const char * mod, const char * iface);

		DWORD FindPattern(std::string moduleName, BYTE* Mask, char* szMask);

		DWORD FindPatternV2(std::string moduleName, std::string pattern);

		DWORD FindTextPattern(std::string moduleName, char* string);

		class VMTManager
		{
		private:
			DWORD	*CustomTable;
			bool	initComplete;
			DWORD	*OriginalTable;
			DWORD	*Instance;

			void* m_instance = nullptr;
			void** m_vtable = nullptr;
			int m_size = 0;
			std::unordered_map<int, void*> m_original_funcsX;
			int		MethodCount(DWORD* InstancePointer);
			
		public:

			void VCProtect(void * address, unsigned int size, unsigned long new_protect, unsigned long * old_protect);

			bool IsHooked(int index);

			void Init(void * instance);
			bool	Initialise(DWORD* InstancePointer);

			DWORD	HookMethod(DWORD NewFunction, int Index);
			void	UnhookMethod(int Index);

			void	RestoreOriginal();
			void	RestoreCustom();

			template<typename T>
			T GetMethod(size_t nIndex)
			{
				return (T)OriginalTable[nIndex];
			}

			DWORD	GetOriginalFunction(int Index);

			template <class T>
			T HookFunction(int index, void* func)
			{
				/// index is out of range or null function pointer
				if (index < 0 || index >= m_size || !func)
					return reinterpret_cast<T>(nullptr);

				/// get the original (this assumes that you dont try to hook the function twice)
				auto original = reinterpret_cast<T>(m_vtable[index]);
				m_original_funcsX[index] = original;

				unsigned long old_protection, tmp;
				VCProtect(&m_vtable[index], sizeof(void*), 0x40, &old_protection); /// 0x40 = PAGE_EXECUTE_READWRITE
				m_vtable[index] = func;
				VCProtect(&m_vtable[index], sizeof(void*), old_protection, &tmp);

				return original;
			}
		};
	};
};

template<typename T>
FORCEINLINE T GetMethod(const void* instance, size_t index)
{
	uintptr_t* vmt = *(uintptr_t**)instance;

	return (T)vmt[index];
}