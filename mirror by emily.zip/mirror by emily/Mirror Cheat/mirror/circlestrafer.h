#pragma once
#include "Hooks.h"
#include "Interfaces.h"
#include "SDK.h"
#include "Hacks.h"

void circlestrafe(CUserCmd* cmd, float* circle_yaw);