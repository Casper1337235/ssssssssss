#pragma once
#include "Hooks.h"
#include "Utilities.h"
#include "Interfaces.h"
#include "Hacks.h"
class LinearExtrapolations
{
public:
	void run();
};
extern LinearExtrapolations linear_extraps;