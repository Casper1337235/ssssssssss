#include "Resolver.h"
#include "Ragebot.h"
#include "Hooks.h"
#include "RenderManager.h"
#include "position_adjust.h"
#include "LagCompensation2.h"
#include "laggycompensation.h"
#include "global_count.h"
#include "position_adjust.h"
#include "Autowall.h"
#ifdef NDEBUG
#define XorStr( s ) ( XorCompileTime::XorString< sizeof( s ) - 1, __COUNTER__ >( s, std::make_index_sequence< sizeof( s ) - 1>() ).decrypt() )
#else
#define XorStr( s ) ( s )
#endif
#include "antiaim.h"
resolver_setup * resolver = new resolver_setup();

namespace global_count
{
	int hits[65] = { 0.f };
	int shots_fired[65] = { 0.f };
	int missed_shots[64] = { 0.f };
	bool didhit[64] = { 0.f };
	bool on_fire;

	int missed;
	int hit;
}

void calculate_angle(Vector src, Vector dst, Vector &angles)
{
	Vector delta = src - dst;
	vec_t hyp = delta.Length2D();
	angles.y = (atan(delta.y / delta.x) * 57.295779513082f);
	angles.x = (atan(delta.z / hyp) * 57.295779513082f);
	angles.x = (atan(delta.z / hyp) * 57.295779513082f);
	angles[2] = 0.0f;
	if (delta.x >= 0.0) angles.y += 180.0f;
}
void NormalizeNumX(Vector &vIn, Vector &vOut)
{
	float flLen = vIn.Length();
	if (flLen == 0) {
		vOut.Init(0, 0, 1);
		return;
	}
	flLen = 1 / flLen;
	vOut.Init(vIn.x * flLen, vIn.y * flLen, vIn.z * flLen);
}

inline float RandomFloat(float min, float max)
{
	static auto fn = (decltype(&RandomFloat))(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat"));
	return fn(min, max);
}
void resolver_setup::preso(IClientEntity * player)
{
	switch (options::menu.aimbot.preso.getindex())
	{
	case 1:
	{
		player->GetEyeAnglesXY()->x = 89;
		//	resolver->resolved_pitch = 89.f;
	}
	break;
	case 2:
	{
		player->GetEyeAnglesXY()->x = -89;
		//	resolver->resolved_pitch = -89.f;
	}
	break;
	case 3:
	{
		player->GetEyeAnglesXY()->x = 0;
		//	resolver->resolved_pitch = 0.f;
	}
	break;
	case 4:
	{

		auto index = player->GetIndex();

		static bool shoot[65];
		static bool untrusted[65];
		static float shoot_time[65];
		static float base_pitch;

		const auto local = hackManager.pLocal();
		if (!local)
			return;

		for (auto i = 0; i < interfaces::engine->GetMaxClients(); ++i)
		{
			static float simtime[65];

			const auto eye = player->GetEyeAnglesXY();

			

			auto pitch = 89.f;

			if (eye->x > 89.f) // you sir, are not trusted
			{
				pitch = 89.f;
			}
			
			if (eye->x < -89.f)
			{
				pitch = -89.f;				
			}		
	
			if (simtime[index] != player->GetSimulationTime())
			{
				base_pitch = eye->x;
			}

			if (player->GetWeapon2())
			{
				if (shoot_time[index] != player->GetWeapon2()->last_shottime()) // check if they shot
				{
					pitch = eye->x;
					shoot[index] = true;

					shoot_time[index] = player->GetWeapon2()->last_shottime(); // suck a Sloavky dick
					//hhh... i miss daniel
				}
				else
				{
					pitch = base_pitch;
					shoot[index] = false;
				}
			}
			else
			{
				shoot[index] = false;
				shoot_time[index] = 0.f; // reset
			}

			player->GetEyeAnglesXY()->x = pitch;
		}
	}
	break;

	}

}

player_info_t GetInfo2(int Index) {
	player_info_t Info;
	interfaces::engine->GetPlayerInfo(Index, &Info);
	return Info;
}

int IClientEntity::sequence_activity(IClientEntity* pEntity, int sequence)
{
	const model_t* pModel = pEntity->GetModel();
	if (!pModel)
		return 0;

	auto hdr = interfaces::model_info->GetStudiomodel(pEntity->GetModel());

	if (!hdr)
		return -1;

	static auto get_sequence_activity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(Utilities::Memory::FindPatternV2("client_panorama.dll", "55 8B EC 53 8B 5D 08 56 8B F1 83"));

	return get_sequence_activity(pEntity, hdr, sequence);
}

float NormalizeFloatToAngle(float input)
{
	for (auto i = 0; i < 3; i++) {
		while (input < -180.0f) input += 360.0f;
		while (input > 180.0f) input -= 360.0f;
	}
	return input;
}

float override_yaw(IClientEntity* player, IClientEntity* local) {
	Vector eye_pos, pos_enemy;
	CalcAngle(player->GetEyePosition(), local->GetEyePosition(), eye_pos);

	if (Render::TransformScreen(player->GetOrigin(), pos_enemy))
	{
		if (GUI.GetMouse().x < pos_enemy.x)
			return (eye_pos.y - 90);
		else if (GUI.GetMouse().x > pos_enemy.x)
			return (eye_pos.y + 90);
	}

}

#define M_PI 3.14159265358979323846
void VectorAnglesBrute(const Vector& forward, Vector &angles)
{
	float tmp, yaw, pitch;
	if (forward[1] == 0 && forward[0] == 0)
	{
		yaw = 0;
		if (forward[2] > 0) pitch = 270; else pitch = 90;
	}
	else
	{
		yaw = (atan2(forward[1], forward[0]) * 180 / M_PI);
		if (yaw < 0) yaw += 360; tmp = sqrt(forward[0] * forward[0] + forward[1] * forward[1]); pitch = (atan2(-forward[2], tmp) * 180 / M_PI);
		if (pitch < 0) pitch += 360;
	} angles[0] = pitch; angles[1] = yaw; angles[2] = 0;
}

Vector calc_angle_trash(Vector src, Vector dst)
{
	Vector ret;
	VectorAnglesBrute(dst - src, ret);
	return ret;
}
template<class T, class U>
inline T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;
	else if (in >= high)
		return high;
	else
		return in;
}
int total_missed[64];
int total_hit[64];
IGameEvent* event = nullptr;
extra s_extra; 

void angle_correction::animstate(IClientEntity * player)
{
	auto* animstate = player->get_animation_state();

	if (!animstate)
		return;

	animstate->m_flEyeYaw = player->GetEyeAnglesXY()->y;

	animstate->m_flFeetYawRate = 0.f;
}

float NormalizeYaw180(float yaw)
{
	if (yaw > 180)
		yaw -= (round(yaw / 360) * 360.f);
	else if (yaw < -180)
		yaw += (round(yaw / 360) * -360.f);

	return yaw;
}
void angle_correction::goalfeetyaw(IClientEntity * player)
{
	animstate(player); //apply animstate corrections before fucking with angles

	auto* animstate = player->get_animation_state();

	if (!animstate)
		return;

	animstate->m_flCurrentFeetYaw = animstate->goal_feet_yaw;

	auto ducking_speed = animstate->speed / (player->max_speed() * 0.340f);

	auto eye_feet_delta = animstate->m_flEyeYaw - animstate->goal_feet_yaw;

	auto fl_running_speed = clamp(animstate->m_flStopToFullRunningFraction, 0.0f, 1.0f);

	auto fl_yaw_modifier = ((animstate->m_flStopToFullRunningFraction * -0.3f) - 0.2f) * fl_running_speed + 1.0f;

	if (animstate->m_fDuckAmount > 0)
	{
		auto fl_ducking_speed =clamp(ducking_speed, 0.0f, 1.0f);
		fl_yaw_modifier = fl_yaw_modifier + ((animstate->m_fDuckAmount * fl_ducking_speed) * (0.5f -
			fl_yaw_modifier));
	}

	auto fl_max_yaw_modifier = fl_yaw_modifier * animstate->velocity_subtract_y;
	auto fl_min_yaw_modifier = fl_yaw_modifier * animstate->velocity_subtract_x;

	if (eye_feet_delta <= fl_max_yaw_modifier)
	{
		if (fl_min_yaw_modifier > eye_feet_delta)
			animstate->goal_feet_yaw = fabs(fl_min_yaw_modifier) + animstate->m_flEyeYaw;
	}
	else
	{
		animstate->goal_feet_yaw = animstate->m_flEyeYaw - fabs(fl_max_yaw_modifier);
	}

	NormalizeYaw180(animstate->goal_feet_yaw);
}

void angle_correction::bodyyawpose(IClientEntity * player)
{
	auto* animstate = player->get_animation_state();

	if (!animstate)
		return;
	auto new_body_yaw_pose = 0.0f;
	auto gfydelta = animstate->m_flEyeYaw - animstate->goal_feet_yaw;

		if (gfydelta < 0)
			new_body_yaw_pose = (gfydelta / max_delta(player, animstate)) * -58.0f;
		else new_body_yaw_pose = (gfydelta / max_delta(player, animstate)) * 58.0f;

		animstate->body_yaw = (new_body_yaw_pose);
}

void angle_correction::emma_resolver(IClientEntity * player)
{
	goalfeetyaw(player);
	bodyyawpose(player);

	auto* animstate = player->get_animation_state();

	if (!animstate)
		return;

	auto fl_running_speed = clamp(animstate->m_flStopToFullRunningFraction, 0.0f, 1.0f);

	auto fl_yaw_modifier = ((animstate->m_flStopToFullRunningFraction * -0.3f) - 0.2f) * fl_running_speed + 1.0f;


	auto max_delta = animstate->velocity_subtract_y * fl_yaw_modifier;
	auto negative_max_delta = animstate->velocity_subtract_x * fl_yaw_modifier;
	//auto eye_angles_y = animstate->eye_angles_y;
	//auto yaw_delta = eye_angles_y - goal_feet_yaw;

	switch (Globals::missedshots[player->GetIndex()] % 3)
	{
	default:
		break;
	case 0:
		animstate->goal_feet_yaw += max_delta;
		break;
	case 1:
		animstate->goal_feet_yaw = animstate->m_flCurrentFeetYaw;
		break;
	case 2:
		animstate->goal_feet_yaw += negative_max_delta;
		break;
	}
}


int IClientEntity::GetSequenceActivity(int sequence)
{
	auto hdr = interfaces::model_info->GetStudiomodel(this->GetModel());

	if (!hdr)
		return -1;

	static auto getSequenceActivity = (DWORD)(Utilities::Memory::FindPatternV2("client_panorama.dll", "55 8B EC 83 7D 08 FF 56 8B F1 74"));
	static auto GetSequenceActivity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(getSequenceActivity);

	return GetSequenceActivity(this, hdr, sequence);
}


float lerp_time()
{
	int ud_rate = interfaces::cvar->FindVar("cl_updaterate")->GetFloat();
	ConVar *min_ud_rate = interfaces::cvar->FindVar("sv_minupdaterate");
	ConVar *max_ud_rate = interfaces::cvar->FindVar("sv_maxupdaterate");
	if (min_ud_rate && max_ud_rate)
		ud_rate = max_ud_rate->GetFloat();
	float ratio = interfaces::cvar->FindVar("cl_interp_ratio")->GetFloat();
	if (ratio == 0)
		ratio = 1.0f;
	float lerp = interfaces::cvar->FindVar("cl_interp")->GetFloat();
	ConVar *c_min_ratio = interfaces::cvar->FindVar("sv_client_min_interp_ratio");
	ConVar *c_max_ratio = interfaces::cvar->FindVar("sv_client_max_interp_ratio");
	if (c_min_ratio && c_max_ratio && c_min_ratio->GetFloat() != 1)
		ratio = clamp(ratio, c_min_ratio->GetFloat(), c_max_ratio->GetFloat());
	return max(lerp, (ratio / ud_rate));
}

bool delta_58(float first, float second)
{
	if (first - second < 58.f && first - second > -58.f)
	{
		return true;
	}
	return false;
}
Vector CalcAngleToEnt(const Vector& vecSource, const Vector& vecDestination)
{
	Vector qAngles;
	Vector delta = Vector((vecSource[0] - vecDestination[0]), (vecSource[1] - vecDestination[1]), (vecSource[2] - vecDestination[2]));
	float hyp = sqrtf(delta[0] * delta[0] + delta[1] * delta[1]);
	qAngles[0] = (float)(atan(delta[2] / hyp) * (180.0f / M_PI));
	qAngles[1] = (float)(atan(delta[1] / delta[0]) * (180.0f / M_PI));
	qAngles[2] = 0.f;
	if (delta[0] >= 0.f)
		qAngles[1] += 180.f;

	return qAngles;
}
float feet_yaw_delta(float first, float second)
{
	return first - second;
}
bool delta_35(float first, float second)
{
	if (first - second <= 35.f && first - second >= -35.f)
	{
		return true;
	}
	return false;
}
bool delta_20(float first, float second)
{
	if (first - second <= 20.f && first - second >= -20.f)
	{
		return true;
	}
	return false;
}
void angle_correction::ac_smart(IClientEntity* pEnt)
{
	static float oldSimtime[65];
	static float storedSimtime[65];
	static float ShotTime[65];
	static float SideTime[65][3];
	static int LastDesyncSide[65];
	static bool Delaying[65];
	static AnimationLayer StoredLayers[64][15];
	static CBaseAnimState * StoredAnimState[65];
	static float StoredPosParams[65][24];
	static Vector oldEyeAngles[65];
	static float oldGoalfeetYaw[65];
	float* PosParams = (float*)((uintptr_t)pEnt + 0x2774);
	bool update = false;
	bool shot = false;

	const auto local = hackManager.pLocal();
	if (!local)
		return;

	static bool jittering[65];

	auto* AnimState = pEnt->get_animation_state();

	if (!AnimState || !pEnt->AnimOverlays() || !PosParams)
		return;

	auto RemapVal = [](float val, float A, float B, float C, float D) -> float
	{
		if (A == B)
			return val >= B ? D : C;
		return C + (D - C) * (val - A) / (B - A);
	};

	//	pEnt->GetEyeAnglesXY()->z = 0.f;


	if (is_slow_walking(pEnt))
	{
		s_extra.current_flag[pEnt->GetIndex()] = correction_flags::SLOW_WALK;
		resolver->enemy_slowwalk = true;
	}
	else
		resolver->enemy_slowwalk = false;
	if (total_missed[pEnt->GetIndex()] > 4)
	{
		resolver->enemy_fake[pEnt->GetIndex()] = false;
		total_missed[pEnt->GetIndex()] = 0;
	}
	if (total_missed[pEnt->GetIndex()] > 1 && total_missed[pEnt->GetIndex()] <= 4)
	{
		resolver->enemy_fake[pEnt->GetIndex()] = true;
	}

	if (storedSimtime[pEnt->GetIndex()] != pEnt->GetSimulationTime())
	{
		jittering[pEnt->GetIndex()] = false;
		pEnt->ClientAnimations(true);
		pEnt->UpdateClientSideAnimation();

		memcpy(StoredPosParams[pEnt->GetIndex()], PosParams, sizeof(float) * 24);
		memcpy(StoredLayers[pEnt->GetIndex()], pEnt->AnimOverlays(), (sizeof(AnimationLayer) * 15));

		oldGoalfeetYaw[pEnt->GetIndex()] = AnimState->goal_feet_yaw;

		if (pEnt->GetWeapon2() && !pEnt->IsKnifeorNade())
		{
			if (ShotTime[pEnt->GetIndex()] != pEnt->GetWeapon2()->GetLastShotTime())
			{
				shot = true;
				ShotTime[pEnt->GetIndex()] = pEnt->GetWeapon2()->GetLastShotTime();
			}
			else
				shot = false;
		}
		else
		{
			shot = false;
			ShotTime[pEnt->GetIndex()] = 0.f;
		}

		float angToLocal = NormalizeYaw180(CalcAngleToEnt(local->GetOrigin(), pEnt->GetOrigin()).y);

		float Back = NormalizeYaw180(angToLocal);
		float DesyncFix = 0;
		float Resim = NormalizeYaw180((0.24f / (pEnt->GetSimulationTime() - oldSimtime[pEnt->GetIndex()]))*(oldEyeAngles[pEnt->GetIndex()].y - pEnt->GetEyeAngles().y));

		if (Resim > 58.f)
			Resim = 58.f;
		if (Resim < -58.f)
			Resim = -58.f;

		if (pEnt->getvelocity().Length2D() > 0.5f && !shot)
		{
			float Delta = NormalizeYaw180(NormalizeYaw180(CalcAngleToEnt(Vector(0, 0, 0), pEnt->getvelocity()).y) - NormalizeYaw180(NormalizeYaw180(AnimState->goal_feet_yaw + RemapVal(PosParams[11], 0, 1, -60, 60)) + Resim));

			int CurrentSide = 0;

			if (Delta < 0)
			{
				CurrentSide = 1;
				SideTime[pEnt->GetIndex()][1] = interfaces::globals->curtime;
			}
			else if (Delta > 0)
			{
				CurrentSide = 2;
				SideTime[pEnt->GetIndex()][2] = interfaces::globals->curtime;
			}

			if (LastDesyncSide[pEnt->GetIndex()] == 1)
			{
				Resim += (58.f - Resim);
				DesyncFix += (58.f - Resim);
			}
			if (LastDesyncSide[pEnt->GetIndex()] == 2)
			{
				Resim += (-58.f - Resim);
				DesyncFix += (-58.f - Resim);
			}

			if (LastDesyncSide[pEnt->GetIndex()] != CurrentSide)
			{
				Delaying[pEnt->GetIndex()] = true;

				if (0.5f < (interfaces::globals->curtime - SideTime[pEnt->GetIndex()][LastDesyncSide[pEnt->GetIndex()]]))
				{
					LastDesyncSide[pEnt->GetIndex()] = CurrentSide;
					Delaying[pEnt->GetIndex()] = false;
				}
			}

			if (!Delaying[pEnt->GetIndex()])
				LastDesyncSide[pEnt->GetIndex()] = CurrentSide;
		}
		else if (!shot)
		{
			float Brute = pEnt->get_lowerbody();

			float Delta = NormalizeYaw180(NormalizeYaw180(Brute - NormalizeYaw180(NormalizeYaw180(AnimState->goal_feet_yaw + RemapVal(PosParams[11], 0, 1, -60, 60))) + Resim));

			if (Delta > 58.f)
				Delta = 58.f;
			if (Delta < -58.f)
				Delta = -58.f;

			Resim += Delta;
			DesyncFix += Delta;

			if (Resim > 58.f)
				Resim = 58.f;
			if (Resim < -58.f)
				Resim = -58.f;
		}

		float Equalized = NormalizeYaw180(NormalizeYaw180(AnimState->goal_feet_yaw + RemapVal(PosParams[11], 0, 1, -59.f, 59.f)) + Resim);

		float JitterDelta = fabs(NormalizeYaw180(oldEyeAngles[pEnt->GetIndex()].y - pEnt->GetEyeAngles().y));

		if (JitterDelta >= 70.f && !shot)
			jittering[pEnt->GetIndex()] = true;

		if (pEnt->team() != local->team() && (pEnt->GetFlags() & FL_ONGROUND))
		{
			if (jittering[pEnt->GetIndex()])
				AnimState->goal_feet_yaw = NormalizeYaw180(pEnt->GetEyeAngles().y + DesyncFix);
			else
				AnimState->goal_feet_yaw = Equalized;

			pEnt->SetLowerBodyYaw(AnimState->goal_feet_yaw);
		}

		StoredAnimState[pEnt->GetIndex()] = AnimState;

		oldEyeAngles[pEnt->GetIndex()] = pEnt->GetEyeAngles();

		oldSimtime[pEnt->GetIndex()] = storedSimtime[pEnt->GetIndex()];

		storedSimtime[pEnt->GetIndex()] = pEnt->GetSimulationTime();

		update = true;
	}

	pEnt->ClientAnimations(false);

	if (pEnt != local && pEnt->team() != local->team() && (pEnt->GetFlags() & FL_ONGROUND))
		pEnt->SetLowerBodyYaw(AnimState->goal_feet_yaw);
	else
		pEnt->SetAbsAngles(Vector(0, pEnt->GetEyeAngles().y, 0));

	AnimState = StoredAnimState[pEnt->GetIndex()];

	memcpy((void*)PosParams, &StoredPosParams[pEnt->GetIndex()], (sizeof(float) * 24));
	memcpy(pEnt->AnimOverlays(), StoredLayers[pEnt->GetIndex()], (sizeof(AnimationLayer) * 15));

	if (pEnt != local && pEnt->team() != local->team() && (pEnt->GetFlags() & FL_ONGROUND) && jittering[pEnt->GetIndex()])
		pEnt->SetAbsAngles(Vector(0, pEnt->GetEyeAngles().y, 0));
	else
		pEnt->SetAbsAngles(Vector(0, oldGoalfeetYaw[pEnt->GetIndex()], 0));

	*reinterpret_cast<int*>(uintptr_t(pEnt) + 0xA30) = interfaces::globals->framecount;
	*reinterpret_cast<int*>(uintptr_t(pEnt) + 0xA28) = 0;
}

bool angle_correction::is_slow_walking(IClientEntity* entity) {
	float velocity_2D[64], old_velocity_2D[64];

	if (entity->getvelocity().Length2D() != velocity_2D[entity->GetIndex()] && entity->getvelocity().Length2D() != NULL) {
		old_velocity_2D[entity->GetIndex()] = velocity_2D[entity->GetIndex()];
		velocity_2D[entity->GetIndex()] = entity->getvelocity().Length2D();
	}

	if (velocity_2D[entity->GetIndex()] > 0.1) {
		int tick_counter[64];

		if (velocity_2D[entity->GetIndex()] == old_velocity_2D[entity->GetIndex()])
			++tick_counter[entity->GetIndex()];
		else
			tick_counter[entity->GetIndex()] = 0;

		while (tick_counter[entity->GetIndex()] > (1 / interfaces::globals->interval_per_tick) * fabsf(0.1f))// should give use 100ms in ticks if their speed stays the same for that long they are definetely up to something..
			return true;

	}
	return false;
}

#define MASK_SHOT_BRUSHONLY			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_DEBRIS)

float NormalizeX(float yaw)
{
	if (yaw != yaw)
		yaw = 0.f;

	return fmod(yaw + 180.f, 360.f) - 180.f;
}

float approach(float cur, float target, float inc) {
	inc = abs(inc);

	if (cur < target)
		return min(cur + inc, target);
	if (cur > target)
		return max(cur - inc, target);

	return target;
}

float angle_difference(float a, float b) {
	auto diff = NormalizeYaw180(a - b);

	if (diff < 180)
		return diff;
	return diff - 360;
}

float approach_angle(float cur, float target, float inc) {
	auto diff = angle_difference(target, cur);
	return approach(cur, cur + diff, inc);
}

int IClientEntity::get_sequence_act(int sequence)
{
	auto hdr = interfaces::model_info->GetStudiomodel(this->GetModel());

	if (!hdr)
		return -1;

	static auto get_sequence_activity = reinterpret_cast< int(__fastcall*)(void*, studiohdr_t*, int) >((DWORD)
		game_utils::pattern_scan(GetModuleHandle("client_panorama.dll"),
			"55 8B EC 53 8B 5D 08 56 8B F1 83"/*"55 8B EC 83 7D 08 FF 56 8B F1 74"*/));
	return get_sequence_activity(this, hdr, sequence);
}
bool angle_correction::solve_desync_simple(IClientEntity* e)
{
	if (!e || e->dormant() || !e->IsAlive())
		return false;

	for (size_t i = 0; i < e->GetNumAnimOverlays(); i++)
	{
		auto layer = e->get_anim_overlay_index(i);
		if (!layer)
			continue;

		if (e->get_sequence_act(layer->m_nSequence) == 979 && layer->m_flWeight == 0.0f && (layer->m_flCycle == 0.0f || layer->m_flCycle != layer->m_flPrevCycle) || layer->m_flWeight == 1.0f && layer->m_flCycle != layer->m_flPrevCycle)
		{
			return true;
		}
	}
	return false;
}
bool angle_correction::breaking_lby_animations(IClientEntity* e)
{
	if (!e || e->is_dormant() || !e->IsAlive())
		return false;

	for (size_t i = 0; i < e->GetNumAnimOverlays(); i++)
	{
		auto layer = e->get_anim_overlay_index(i);

		if (!layer )
			continue;
		if (e->get_sequence_act(layer->m_nSequence) == 979)
		{
			if (layer->m_flCycle != layer->m_flPrevCycle || layer->m_flWeight == 1.f)
				return true;
		}
	}

	return false;
}

HANDLE _out = NULL, _old_out = NULL;
bool ConsolePrint(const char* fmt, ...)
{
	if (!_out)
		return false;

	char buf[1024];
	va_list va;

	va_start(va, fmt);
	_vsnprintf_s(buf, 1024, fmt, va);
	va_end(va);//im missing 5 chromosomes

	return !!WriteConsoleA(_out, buf, static_cast<DWORD>(strlen(buf)), nullptr, nullptr);
}

float angle_correction::max_delta(IClientEntity* player, CBaseAnimState* anim_state) {
	if (!player || !anim_state || !player->GetBasePlayerAnimState())
		return 0.f;

	auto ducking_speed = anim_state->speed_2d / (player->max_speed() * 0.340f);

	auto speed_fraction = max(0.0f, min(anim_state->m_flFeetSpeedForwardsOrSideWays, 1.0f));

	auto fl_yaw_modifier = ((anim_state->m_flStopToFullRunningFraction * -0.3f) - 0.2f) * speed_fraction + 1.0f;

	if (anim_state->m_fDuckAmount > 0) {
		auto fl_ducking_speed = clamp(ducking_speed, 0.0f, 1.0f);
		fl_yaw_modifier = fl_yaw_modifier + ((anim_state->m_fDuckAmount * fl_ducking_speed) * (0.5f -
			fl_yaw_modifier));
	}

	auto delta = anim_state->velocity_subtract_y * fl_yaw_modifier;

	return delta;
}

float flAngleMod(float flAngle)
{
	return((360.0f / 65536.0f) * ((int32_t)(flAngle * (65536.0f / 360.0f)) & 65535));
}
float ApproachAngle(float target, float value, float speed)
{
	target = flAngleMod(target);
	value = flAngleMod(value);

	float delta = target - value;

	// Speed is assumed to be positive
	if (speed < 0)
		speed = -speed;

	if (delta < -180)
		delta += 360;
	else if (delta > 180)
		delta -= 360;

	if (delta > speed)
		value += speed;
	else if (delta < -speed)
		value -= speed;
	else
		value = target;

	return value;
}

player_info_t GetInfo_x(int Index) {
	player_info_t Info;
	interfaces::engine->GetPlayerInfo(Index, &Info);
	return Info;
}


void angle_correction::mirror_aesthetic_console()
{
	interfaces::cvar->ConsoleColorPrintf(Color(250, 250, 250, 255), "[");
	interfaces::cvar->ConsoleColorPrintf(Color(210, 10, 250, 255), "mir");
	interfaces::cvar->ConsoleColorPrintf(Color(10, 190, 250, 255), "ror");
	interfaces::cvar->ConsoleColorPrintf(Color(250, 250, 250, 255), "]");
}

void angle_correction::resolve_mirror_fakeangles(IClientEntity * player)
{
	float moving_lby[65] = { FLT_MAX };
	float delta[65] = { FLT_MAX };
	float old_lby[65] = { FLT_MAX };
	float last_sim[64] = { 0.f };

	bool fake979[65] = { false };
	bool nofake[65] = { false };
	float lby[65] = { player->get_lowerbody() };
	bool is_moving = player->getvelocity().Length2D() > 0.1f;
	bool was_moving[65] = { false };
	if (old_lby[player->GetIndex()] == FLT_MAX)
	{
		old_lby[player->GetIndex()] = lby[player->GetIndex()];
	}

	if (old_lby[player->GetIndex()] != lby[player->GetIndex()])
	{
		old_lby[player->GetIndex()] = lby[player->GetIndex()];
	}
	const auto sim = player->GetSimulationTime();
	if (sim - last_sim[player->GetIndex()] >= 1)
	{
		if (sim - last_sim[player->GetIndex()] == 1)
		{
			nofake[player->GetIndex()] = true;
		}
		last_sim[player->GetIndex()] = sim;
	}

	if (nofake[player->GetIndex()])
		return;

	bool lbyupdate = old_lby[player->GetIndex()] != lby[player->GetIndex()];

	switch (is_moving)
	{
	case true:
	{


		if (player->getvelocity().Length2D() <= 26.f && moving_lby[player->GetIndex()] != FLT_MAX && was_moving[player->GetIndex()])
		{
			player->GetEyeAnglesXY()->y = moving_lby[player->GetIndex()];
		}
		else
		{
			was_moving[player->GetIndex()] = true;
			moving_lby[player->GetIndex()] = player->get_lowerbody();
			player->GetEyeAnglesXY()->y = player->get_lowerbody();
		}

	}
	break;

	case false:
	{
		if (moving_lby[player->GetIndex()] != FLT_MAX)
		{
			if (breaking_lby_animations(player))
			{
				if (delta_35(moving_lby[player->GetIndex()], lby[player->GetIndex()]))
					fake979[player->GetIndex()] = true;
			}
		}
		delta[player->GetIndex()] = lby[player->GetIndex()] - old_lby[player->GetIndex()];
		
		if (breaking_lby_animations(player))
		{
			if (was_moving[player->GetIndex()])
			{
				switch (Globals::missedshots[player->GetIndex()] % 4)
				{
				case 0: player->GetEyeAnglesXY()->y = moving_lby[player->GetIndex()];
					break;
				case 1: player->GetEyeAnglesXY()->y = moving_lby[player->GetIndex()] - 20;
					break;
				case 2: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 120;
					break;
				case 3: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - delta[player->GetIndex()];
					break;
				case 4: player->GetEyeAnglesXY()->y = lby[player->GetIndex()];
					break;
				}
			}
			else
			{
				if (delta[player->GetIndex()] != FLT_MAX)
					player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - delta[player->GetIndex()];
				else
					player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 120;
			}
			
		}
		else
		{
			if (solve_desync_simple(player))
			{

				if (was_moving[player->GetIndex()])
				{
					switch (Globals::missedshots[player->GetIndex()] % 4)
					{
					case 0: player->GetEyeAnglesXY()->y = moving_lby[player->GetIndex()];
						break;
					case 1: player->GetEyeAnglesXY()->y = moving_lby[player->GetIndex()] - 20;
						break;
					case 2: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 90;
						break;
					case 3: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 100;
						break;
					case 4: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - delta[player->GetIndex()];
						break;
					}
				}
				else
				{
					if (delta[player->GetIndex()] != FLT_MAX)
						player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - delta[player->GetIndex()];
					else
						player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 100;
				}

			}
			else
			{
				switch (Globals::missedshots[player->GetIndex()] % 4)
				{
				case 0: player->GetEyeAnglesXY()->y = lby[player->GetIndex()];
					break;
				case 1: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 20;
					break;
				case 2: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] - 35;
					break;
				case 3: player->GetEyeAnglesXY()->y = lby[player->GetIndex()] + 20;
					break;
				case 4: player->GetEyeAnglesXY()->y = lby[player->GetIndex()];
					break;
				}
			}
		}
		
	}
	break;
	}




}


void angle_correction::resolve_mirror_primary(IClientEntity * player)
{

	float moving_lby[65] = { FLT_MAX };
	float delta[65] = { FLT_MAX };
	float old_lby[65] = { FLT_MAX };
	float update_time[65] = { FLT_MAX };
	float original_lby[65] = { FLT_MAX };
	bool lby_flick[65] = { false };
	bool fake = false;
	bool did_move[65] = { false };

	bool is_moving = player->getvelocity().Length2D() > 0.1f && (player->GetFlags() & FL_ONGROUND);

	const auto animation = player->get_animation_state();

	if (!animation)
		return;

	if (player->get_choked_ticks() < 1)
		return;

	if (is_moving)
	{
		if (moving_lby[player->GetIndex()] != player->get_lowerbody())
			moving_lby[player->GetIndex()] = player->get_lowerbody();

		old_lby[player->GetIndex()] = player->get_lowerbody();
		did_move[player->GetIndex()] = true;
	}


	if (player->getvelocity().Length2D() < 1.1f && (player->GetFlags() & FL_ONGROUND))
	{
		if (original_lby[player->GetIndex()] == FLT_MAX)
		{
			original_lby[player->GetIndex()] = player->get_lowerbody();
		}

		if (old_lby[player->GetIndex()] != player->get_lowerbody())
		{
			delta[player->GetIndex()] = old_lby[player->GetIndex()] - player->get_lowerbody();
			lby_flick[player->GetIndex()] = true;
			old_lby[player->GetIndex()] = player->get_lowerbody();
		}
		else
			lby_flick[player->GetIndex()] = false;
	}
	else
	{
		if (original_lby[player->GetIndex()] != player->get_lowerbody())
			original_lby[player->GetIndex()] = player->get_lowerbody();
	}

#pragma region i want to die.

	if (player->getvelocity().Length2D() < 1.1f && (delta[player->GetIndex()] < 160 && delta[player->GetIndex()] > -160))
	{
		if (breaking_lby_animations(player))
		{
			if (lby_flick[player->GetIndex()])
			{
				player->GetEyeAnglesXY()->y = player->get_lowerbody();
			}
			else
			{
				if (Globals::missedshots[player->GetIndex()] <= 2)
				{
					player->GetEyeAnglesXY()->y = player->get_lowerbody() - delta[player->GetIndex()] - (Globals::missedshots[player->GetIndex()] == 2 ? 30 : 0 );
				}

				else
				{
					player->GetEyeAnglesXY()->y = player->get_lowerbody();
				}
			}
		}

		else if (solve_desync_simple(player)) // experimental. Low delta lby break related animations.
		{	
		//	if ((delta[player->GetIndex()] < 120.f && delta[player->GetIndex()] >= 90.f) || (delta[player->GetIndex()] > -120.f && delta[player->GetIndex()] <= -90.f))
			{
				if (Globals::missedshots[player->GetIndex()] < 2)
				{
					player->GetEyeAnglesXY()->y = player->get_lowerbody() - 29;
				}

				if (Globals::missedshots[player->GetIndex()] >= 2)
				{
					player->GetEyeAnglesXY()->y = player->get_lowerbody() - delta[player->GetIndex()];
				}
			}
/*
			else
			{
				switch (Globals::missedshots[player->GetIndex()])
				{
					//skip the first
				case 1: player->GetEyeAnglesXY()->y -= 30.f;
					break;
				case 2: player->GetEyeAnglesXY()->y += 50.f;
					break;
				case 3: player->GetEyeAnglesXY()->y -= 29.f;
					break;
				case 4: player->GetEyeAnglesXY()->y -= delta[player->GetIndex()];
					break;
				case 5: player->GetEyeAnglesXY()->y -= 50.f;
					break;
					// skip the sixth
				}
			}
*/
		}
		
	
	}

	else
	{
		float close_yaw = ApproachAngle(player->get_lowerbody(), animation->goal_feet_yaw, (animation->m_flStopToFullRunningFraction * 20.0f) + 30.0f *animation->m_flLastClientSideAnimationUpdateTime);
		for (size_t i = 0; i < player->GetNumAnimOverlays(); i++)
		{
			auto layer = player->get_anim_overlay_index(i);

			if (!layer)
				continue;

			if (player->get_sequence_act(layer->m_nSequence) == 979 && player->get_sequence_act(layer->m_nSequence) != 981)
			{
				resolver->enemy_fake[player->GetIndex()] = true;
				player->GetEyeAnglesXY()->y = player->get_lowerbody() - (player->get_lowerbody() - old_lby[player->GetIndex()]) + (Globals::missedshots[player->GetIndex()] < 2 ? 20 : -20.f);
			}
			else
			{
				switch (Globals::missedshots[player->GetIndex()] % 7)
				{
				case 0: player->GetEyeAnglesXY()->y = player->get_lowerbody() - 25;
					break;
				case 1: player->GetEyeAnglesXY()->y -= 34.f;
					break;
				case 2: player->GetEyeAnglesXY()->y += 40.f;
					break;
				case 3: { resolver->enemy_fake[player->GetIndex()] = true, player->GetEyeAnglesXY()->y = close_yaw; }
					break;
				case 4: player->GetEyeAnglesXY()->y -= max_delta(player, animation);
					break;
				case 5: player->GetEyeAnglesXY()->y += 30.f;
					break;
				case 6: player->GetEyeAnglesXY()->y -= 20.f;
					break;
				case 7:  player->GetEyeAnglesXY()->y -= 35.f;
					break;
			//	default: player->GetEyeAnglesXY()->y = player->GetLowerBodyYaw(); // because when moving, the :b:sync is based off lby
				}
			}
		}
		
	}

}

void angle_correction::AnimationFix(IClientEntity* pEnt)
{
	if (pEnt != hackManager.pLocal())
	{
		auto player_index = pEnt->GetIndex() - 1;

		pEnt->ClientAnimations(true);

		auto old_curtime = interfaces::globals->curtime;
		auto old_frametime = interfaces::globals->frametime;

		interfaces::globals->curtime = pEnt->GetSimulationTime();
		interfaces::globals->frametime = interfaces::globals->interval_per_tick;

		auto player_animation_state = pEnt->get_animation_state();
		auto player_model_time = reinterpret_cast<int*>(player_animation_state + 112);
		if (player_animation_state != nullptr && player_model_time != nullptr)
			if (*player_model_time == interfaces::globals->framecount)
				*player_model_time = interfaces::globals->framecount - 1;


		pEnt->UpdateClientSideAnimation();

		interfaces::globals->curtime = old_curtime;
		interfaces::globals->frametime = old_frametime;

		//pEnt->SetAbsAngles(Vector(0, player_animation_state->m_flGoalFeetYaw, 0));

		pEnt->ClientAnimations(false);
	}

}


void update_state(CBaseAnimState * state, Vector angles) {
	using Fn = void(__vectorcall*)(void *, void *, float, float, float, void *);
	static auto fn = reinterpret_cast<Fn>(game_utils::pattern_scan("client_panorama.dll", "55 8B EC 83 E4 F8 83 EC 18 56 57 8B F9 F3 0F 11 54 24"));
	fn(state, nullptr, 0.0f, angles[1], angles[0], nullptr);
}

void HandleBackUpResolve(IClientEntity* pEnt) {

	

	const auto player_animation_state = pEnt->get_animation_state();

	if (!player_animation_state)
		return;

	float m_flLastClientSideAnimationUpdateTimeDelta = fabs(player_animation_state->m_iLastClientSideAnimationUpdateFramecount - player_animation_state->m_flLastClientSideAnimationUpdateTime);

	auto v48 = 0.f;

	if (player_animation_state->m_flFeetSpeedForwardsOrSideWays >= 0.0f)
	{
		v48 = fminf(player_animation_state->m_flFeetSpeedForwardsOrSideWays, 1.0f);
	}
	else
	{
		v48 = 0.0f;
	}

	float v49 = ((player_animation_state->m_flStopToFullRunningFraction * -0.30000001) - 0.19999999) * v48;

	float flYawModifier = v49 + 1.0;

	if (player_animation_state->m_fDuckAmount > 0.0)
	{
		float v53 = 0.0f;

		if (player_animation_state->m_flFeetSpeedUnknownForwardOrSideways >= 0.0)
		{
			v53 = fminf(player_animation_state->m_flFeetSpeedUnknownForwardOrSideways, 1.0);
		}
		else
		{
			v53 = 0.0f;
		}
	}

	float flMaxYawModifier = player_animation_state->pad10[516] * flYawModifier;
	float flMinYawModifier = player_animation_state->pad10[512] * flYawModifier;

	float newFeetYaw = 0.f;

	auto eyeYaw = player_animation_state->m_flEyeYaw;

	auto lbyYaw = player_animation_state->goal_feet_yaw;

	float eye_feet_delta = fabs(eyeYaw - lbyYaw);

	if (eye_feet_delta <= flMaxYawModifier)
	{
		if (flMinYawModifier > eye_feet_delta)
		{
			newFeetYaw = fabs(flMinYawModifier) + eyeYaw;
		}
	}
	else
	{
		newFeetYaw = eyeYaw - fabs(flMaxYawModifier);
	}

	float v136 = fmod(newFeetYaw, 360.0);

	if (v136 > 180.0)
	{
		v136 = v136 - 360.0;
	}

	if (v136 < 180.0)
	{
		v136 = v136 + 360.0;
	}

	player_animation_state->goal_feet_yaw = v136;

	/*static int stored_yaw = 0;

	if (pEnt->GetEyeAnglesPointer()->y != stored_yaw) {
	if ((pEnt->GetEyeAnglesPointer()->y - stored_yaw > 120)) { // Arbitrary high angle value.
	if (pEnt->GetEyeAnglesPointer()->y - stored_yaw > 120) {
	pEnt->GetEyeAnglesPointer()->y = pEnt->GetEyeAnglesPointer()->y - (pEnt->GetEyeAnglesPointer()->y - stored_yaw);
	}

	stored_yaw = pEnt->GetEyeAnglesPointer()->y;
	}
	}*/
	//if (pEnt->GetVelocity().Length2D() > 0.1f)
	//{
	//	player_animation_state->m_flGoalFeetYaw = ApproachAngle(pEnt->GetLowerBodyYaw(), player_animation_state->m_flGoalFeetYaw, (player_animation_state->m_flStopToFullRunningFraction * 20.0f) + 30.0f *player_animation_state->m_flLastClientSideAnimationUpdateTime);
	//}
	//else
	//{
	//	player_animation_state->m_flGoalFeetYaw = ApproachAngle(pEnt->GetLowerBodyYaw(), player_animation_state->m_flGoalFeetYaw, (m_flLastClientSideAnimationUpdateTimeDelta * 100.0f));
	//}
	//if (Globals::MissedShots[pEnt->EntIndex()] > 3) {
	//	switch (Globals::MissedShots[pEnt->EntIndex()] % 4) {
	//	case 0: pEnt->GetEyeAnglesPointer()->y = pEnt->GetEyeAnglesPointer()->y + 45; break;
	//	case 1: pEnt->GetEyeAnglesPointer()->y = pEnt->GetEyeAnglesPointer()->y - 45; break;
	//	case 2: pEnt->GetEyeAnglesPointer()->y = pEnt->GetEyeAnglesPointer()->y - 30; break;
	//	case 3: pEnt->GetEyeAnglesPointer()->y = pEnt->GetEyeAnglesPointer()->y + 30; break;
	//	}
	//}
}

void resolver_setup::FSN(IClientEntity* pEntity, ClientFrameStage_t stage)
{

	if (!interfaces::engine->IsConnected() || !interfaces::engine->IsInGame())
		return;
	if (!options::menu.aimbot.AimbotEnable.getstate() || options::menu.aimbot.resolver.getindex() < 1)
		return;

	angle_correction ac;

	if (stage == ClientFrameStage_t::FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{
		for (int i = 1; i < 65; i++)
		{
			pEntity = (IClientEntity*)interfaces::ent_list->get_client_entity(i);

			if (!pEntity->isValidPlayer() || pEntity->team() == hackManager.pLocal()->team() || pEntity->dormant())
				continue;

			if (pEntity->GetOrigin() == Vector(0, 0, 0))
				continue;

			if (options::menu.aimbot.preso.getindex() > 0)
			{
				resolver_setup::preso(pEntity);
			}

			switch (options::menu.aimbot.resolver.getindex())
			{		
				case 1:
				{				
					ac.resolve_mirror_primary(pEntity); // spin on my dick like a beyblade, uh				
				}
				break;
			
				case 2:
				{
					ac.resolve_mirror_fakeangles(pEntity); 			
				}
				break;

				case 3:
				{
					supremacydump(hackManager.pLocal(), pEntity); // fatality resolver, aporx. 2-3 months old
				}
				break;

				case 4:
				{
					ac.emma_resolver(pEntity);
				}
				break;
			}
		}

	}
/*
			case 3:
				{
					fatality(hackManager.pLocal(), pEntity);
				}
				break;

*/
}

void resolver_setup::supremacydump(IClientEntity * localplayer, IClientEntity * enemy)
{


	auto animstate = localplayer->GetBasePlayerAnimState();
	if (animstate)
	{                                             // inlined max_desync_delta
		float v9 = fabs(animstate->m_iLastClientSideAnimationUpdateFramecount - animstate->m_flLastClientSideAnimationUpdateTime);
		float speedfraction = 0.0;
		if (animstate->m_flFeetSpeedForwardsOrSideWays < 0.0)
			speedfraction = 0.0;
		else
			speedfraction = animstate->m_flFeetSpeedForwardsOrSideWays;

		float v2 = (animstate->m_flStopToFullRunningFraction * -0.30000001 - 0.19999999) * speedfraction;
		float v18 = v2;
		float v3 = v2 + 1.0;
		float v23 = v3;
		if (animstate->m_fDuckAmount > 0.0)
		{
			float v29 = 0.0;
			if (animstate->m_flFeetSpeedUnknownForwardOrSideways < 0.0)
				v29 = 0.0;
			else
				v29 = fminf((animstate->m_flFeetSpeedUnknownForwardOrSideways), 0x3F800000);
		}

		if (localplayer)
		{
			for (int i = 1; i < interfaces::engine->GetMaxClients(); ++i)
			{
				if (enemy)// dormant
				{
					float v28 = enemy->GetEyeAnglesXY()->y == 0.0 ? -58 : 58;
					if (v28)
						return;
					float v27 = enemy->GetEyeAnglesXY()->y == 0.0 ? -89 : 89;
					if (v27)
						return;
					float v26 = enemy->GetEyeAnglesXY()->y == 0.0 ? -79 : 79;
					if (v26)
						return;
					float v25 = enemy->GetEyeAnglesXY()->y == 0.0 ? -125 : 125;
					if (v25)
						return;
					float v24 = enemy->GetEyeAnglesXY()->y == 0.0 ? -78 : 78;
					if (v24)
						return;
				}
			}
			float v8 = 0;
			float v7 = 0;
			float v6 = 0;
			for (size_t i = 0; i < enemy->GetNumAnimOverlays(); i++)
			{
				auto layer = enemy->get_anim_overlay_index(i);
				if (!layer)
					continue;

				if (enemy->get_sequence_act(layer->m_nSequence) == 979 && (layer->m_flPrevCycle) != (layer->m_flCycle))
					v6 = enemy->get_lowerbody();
			}
			float v20 = (animstate->velocity_subtract_z) * v23;
			float a1 = (animstate->velocity_subtract_y) * v23;
			float v30 = 0.0;
			float eye_angles_y = animstate->m_flEyeYaw;
			float goal_feet_yaw = animstate->goal_feet_yaw;
			float v22 = fabs(eye_angles_y - goal_feet_yaw);
			if (v20 < v22)
			{
				float v11 = fabs(v20);
				v30 = eye_angles_y - v11;
			}
			else if (a1 > v22)
			{
				float v12 = fabs(a1);
				v30 = v12 + eye_angles_y;
			}
			float v36 = std::fmodf((v30), 360.0);
			if (v36 > 180.0)
				v36 = v36 - 360.0;
			if (v36 < 180.0)
				v36 = v36 + 360.0;
			animstate->goal_feet_yaw = v36;
			if (Globals::missedshots[enemy->GetIndex()] > 2)
			{
				int v19 = Globals::missedshots[enemy->GetIndex()] % 4;
				switch (v19)
				{
				case 0:
					animstate->goal_feet_yaw = animstate->goal_feet_yaw + 45.0;
					break;
				case 1:
					animstate->goal_feet_yaw = animstate->goal_feet_yaw - 45.0;
					break;
				case 2:
					animstate->goal_feet_yaw = animstate->goal_feet_yaw - 30.0;
					break;
				case 3:
					animstate->goal_feet_yaw = animstate->goal_feet_yaw + 30.0;
					break;
				default:
					return;
				}
			}
		}
	}
}

