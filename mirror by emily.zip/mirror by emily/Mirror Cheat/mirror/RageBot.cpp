#include "RageBot.h"
#include "RenderManager.h"
#include "Resolver.h"
#include "Autowall.h"
#include "position_adjust.h"
#include <iostream>
#include <time.h>
#include "UTIL Functions.h"
#include "xostr.h"
#include <chrono>
#include "Hooks.h"
#include "global_count.h"
#include "laggycompensation.h"
#include "MD5.cpp"
//#include "otr_awall.h"
#include "antiaim.h"
#include "fakelag.h"
#include "experimental.h"
#include "lin_extp.h"
#include "MiscHacks.h"
#include "newbacktrack.h"
//float bigboi::current_yaw;

float current_desync;
Vector LastAngleAA2;
static bool dir = false;
static bool back = false;
static bool up = false;
static bool jitter = false;

static bool backup = false;
static bool default_aa = true;
static bool panic = false;
float hitchance_custom;
#define TICK_INTERVAL			(interfaces::globals->interval_per_tick)
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )
CAimbot * ragebot = new CAimbot;
c_newbacktrack * new_backtrack = new c_newbacktrack;
extra * ext = new extra;
void CAimbot::Init()
{
	IsAimStepping = false;
	IsLocked = false;
	TargetID = -1;
}

void CAimbot::Draw()
{
}
float curtime_fixed(CUserCmd* ucmd) {
	auto local_player = interfaces::ent_list->get_client_entity(interfaces::engine->GetLocalPlayer());
	static int g_tick = 0;
	static CUserCmd* g_pLastCmd = nullptr;
	if (!g_pLastCmd || g_pLastCmd->hasbeenpredicted) {
		g_tick = local_player->GetTickBase();
	}
	else {
		++g_tick;
	}
	g_pLastCmd = ucmd;
	float curtime = g_tick * interfaces::globals->interval_per_tick;
	return curtime;
}

void RandomSeed(UINT seed)
{
	typedef void(*RandomSeed_t)(UINT);
	static RandomSeed_t m_RandomSeed = (RandomSeed_t)GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomSeed");
	m_RandomSeed(seed);
	return;
}

void CAimbot::auto_revolver(CUserCmd* m_pcmd) // credits: https://steamcommunity.com/id/x-87
{
	auto m_local = hackManager.pLocal();
	auto m_weapon = m_local->GetWeapon2();
	if (!m_weapon)
		return;

	if (!shot_this_tick && *m_weapon->GetItemDefinitionIndex() == WEAPON_REVOLVER)
	{

		float flPostponeFireReady = m_weapon->GetFireReadyTime();
		if (flPostponeFireReady > 0 && flPostponeFireReady - 1 < interfaces::globals->curtime)
		{
			m_pcmd->buttons &= ~IN_ATTACK;
		}
		static int delay = 0;
		delay++;

		if (delay <= 15)
			m_pcmd->buttons |= IN_ATTACK;
		else
			delay = 0;

	}
	else
	{
		if (*m_weapon->GetItemDefinitionIndex() == WEAPON_REVOLVER)
		{
			static int delay = 0;
			delay++;

			if (delay <= 15)
				m_pcmd->buttons |= IN_ATTACK;
			else
				delay = 0;
		}
	}
}


bool IsAbleToShoot(IClientEntity* pLocal)
{
	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());
	if (!pLocal)return false;
	if (!pWeapon)return false;
	float flServerTime = pLocal->GetTickBase() * interfaces::globals->interval_per_tick;
	return (!(pWeapon->GetNextPrimaryAttack() > flServerTime));
}
float CAimbot::hitchance()
{
	float hitchance = 101;
	auto m_local = hackManager.pLocal();
	auto pWeapon = m_local->GetWeapon2();
	if (pWeapon)
	{
		if (options::menu.aimbot.AccuracyHitchance.getvalue() > 0)
		{
			float inaccuracy = pWeapon->GetInaccuracy();
			if (inaccuracy == 0) inaccuracy = 0.0000001;
			inaccuracy = 1 / inaccuracy;
			hitchance = inaccuracy;
		}
		return hitchance;
	}
}
bool CAimbot::CanOpenFire(IClientEntity * local)
{

	C_BaseCombatWeapon* entwep = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(local->GetActiveWeaponHandle());
	float flServerTime = (float)local->GetTickBase() * interfaces::globals->interval_per_tick;
	float flNextPrimaryAttack = entwep->GetNextPrimaryAttack();
	std::cout << flServerTime << " " << flNextPrimaryAttack << std::endl;
	return !(flNextPrimaryAttack > flServerTime);
}

template<class T, class U>
inline T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;
	else if (in >= high)
		return high;
	else
		return in;
}

float GetLerpTimeX()
{
	int ud_rate = interfaces::cvar->FindVar("cl_updaterate")->GetFloat();
	ConVar *min_ud_rate = interfaces::cvar->FindVar("sv_minupdaterate");
	ConVar *max_ud_rate = interfaces::cvar->FindVar("sv_maxupdaterate");
	if (min_ud_rate && max_ud_rate)
		ud_rate = max_ud_rate->GetFloat();
	float ratio = interfaces::cvar->FindVar("cl_interp_ratio")->GetFloat();
	if (ratio == 0)
		ratio = 1.0f;
	float lerp = interfaces::cvar->FindVar("cl_interp")->GetFloat();
	ConVar *c_min_ratio = interfaces::cvar->FindVar("sv_client_min_interp_ratio");
	ConVar *c_max_ratio = interfaces::cvar->FindVar("sv_client_max_interp_ratio");
	if (c_min_ratio && c_max_ratio && c_min_ratio->GetFloat() != 1)
		ratio = clamp(ratio, c_min_ratio->GetFloat(), c_max_ratio->GetFloat());
	return max(lerp, (ratio / ud_rate));
}
void CAimbot::Move(CUserCmd *pCmd, bool &bSendPacket)
{
	IClientEntity* pLocalEntity = (IClientEntity*)interfaces::ent_list->get_client_entity(interfaces::engine->GetLocalPlayer());
	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	if (!interfaces::engine->IsConnected() || !interfaces::engine->IsInGame() || !pLocalEntity->isValidPlayer())
		return;

	c_fakelag->Fakelag(pCmd, bSendPacket);

	if (!pWeapon)
		return;

	if (options::menu.misc.AntiAimEnable.getstate())
	{
		static int ChokedPackets = 1;
		//	std::vector<dropdownboxitem> spike = options::menu.MiscTab.fl_spike.items;

		if ((ChokedPackets < 1 && pLocalEntity->GetHealth() <= 0.f && !(pWeapon->IsKnife() || pWeapon->IsC4())))
		{
			bSendPacket = false;
		}

		else
		{		
			if (pLocalEntity->IsAlive() && pLocalEntity->GetMoveType() != MOVETYPE_LADDER)
			{
				c_antiaim->DoAntiAim(pCmd, bSendPacket);
			}
			ChokedPackets = 1;
		}
	}


	if (options::menu.aimbot.AimbotEnable.getstate())
	{
		DoAimbot(pCmd, bSendPacket);
		DoNoRecoil(pCmd, bSendPacket);
		auto_revolver(pCmd);
	}

	if (options::menu.misc.OtherSafeMode.getindex() == 1)
	{
		Vector AddAngs = pCmd->viewangles - LastAngle;
		if (AddAngs.Length2D() > 39.0f)
		{
			Normalize(AddAngs, AddAngs);
			AddAngs *= 39.f;
			pCmd->viewangles = LastAngle + AddAngs;
			game_utils::NormaliseViewAngle(pCmd->viewangles);
		}
	}
	LastAngle = pCmd->viewangles;
}
inline float FastSqrt(float x)
{
	unsigned int i = *(unsigned int*)&x;
	i += 127 << 23;
	i >>= 1;
	return *(float*)&i;
}
#define square( x ) ( x * x )
void ClampMovement(CUserCmd* pCommand, float fMaxSpeed)
{
	if (fMaxSpeed <= 0.f)
		return;
	float fSpeed = (float)(FastSqrt(square(pCommand->forwardmove) + square(pCommand->sidemove) + square(pCommand->upmove)));
	if (fSpeed <= 0.f)
		return;
	if (pCommand->buttons & IN_DUCK)
		fMaxSpeed *= 2.94117647f;
	if (fSpeed <= fMaxSpeed)
		return;
	float fRatio = fMaxSpeed / fSpeed;
	pCommand->forwardmove *= fRatio;
	pCommand->sidemove *= fRatio;
	pCommand->upmove *= fRatio;
}

void CAimbot::sim_time_delay(IClientEntity* entity)
{
	float old_sim[65] = { 0.f };
	float current_sim[65] = { entity->GetSimulationTime() };

	if (entity->m_flOldSimulationTime() != current_sim[entity->GetIndex()])
	{
		can_shoot = true;
		shot_refined = true;
	//	old_sim[entity->GetIndex()] = current_sim[entity->GetIndex()];
	}
	else
	{
		can_shoot = false;
		shot_refined = false;
	}
}

void CAimbot::delay_shot(IClientEntity* entity, CUserCmd* pcmd)
{
	float old_sim[65] = { 0.f };
	float current_sim[65] = { entity->GetSimulationTime() };

	bool lag_comp;

	int index = options::menu.aimbot.delay_shot.getindex();

	switch (index)
	{
	case 1:
	{
		sim_time_delay(entity);
	}
	break;

	case 2: // bameware
	{
		Vector vec_position[65], origin_delta[65];

		if (entity->m_VecORIGIN() != vec_position[entity->GetIndex()])
		{
			origin_delta[entity->GetIndex()] = entity->m_VecORIGIN() - vec_position[entity->GetIndex()];
			vec_position[entity->GetIndex()] = entity->m_VecORIGIN();

			lag_comp = fabs(origin_delta[entity->GetIndex()].Length()) > 64;
		}

		if (lag_comp && entity->getvelocity().Length2D() > 300)
		{
			can_shoot = false;
		}
		else
			can_shoot = true;
	}
	break;

	case 3:
	{
		can_shoot = true;
	}
	break;
	}

}

namespace debug_helpers // will not be used for now
{
	auto hitbox_to_String = [](int hitgroup) -> std::string
	{
		switch (hitgroup)
		{
		case 0:
		{
			return "HEAD";
		}
		case 1:
			return "NECK";
		case 2:
			return "PELVIS";
		case 3:
			return "STOMACH";
		case 5:
			return "LOWER CHEST";
		case 6:
			return "UPPER CHEST";
		case 7:
			return "THIGHS";
		case 8:
			return"THIGHS";
		case 11:
			return "LEGS";
		case 12:
			return "LEGS";
		case 16:
			return "ARMS";
		case 17:
			return "ARMS";
		default:
			return "BODY";
		}
	};


}

/*
void CAimbot::mirror_console_debug(IClientEntity * the_nignog)
{
bool gay = backtracking->good_tick(TIME_TO_TICKS(pTarget->GetSimulationTime() + backtracking->GetLerpTime()));
bool delayshot = options::menu.aimbot.delay_shot.getindex() != 0;
bool sw = the_nignog->GetVelocity().Length2D() < 50.f && the_nignog->GetVelocity().Length2D() > 25.f;

int c = hitchance() / 1.5;
int s = the_nignog->GetVelocity().Length2D();
int h = options::menu.aimbot.AccuracyHitchance.GetValue();
std::string EVENT_2 = " [ Mirror Event ] Shot at hitbox [ ";
std::string one = debug_helpers::hitbox_to_String(HitBox);;
std::string two = " ] with an actual hit chance of [ ";
std::string three = std::to_string(c);
std::string four = " ] and a configured value of [ ";
std::string nn = std::to_string(h);
std::string ffs = " ]";
//----------------------------------------------
std::string EVENT_1 = " [ Mirror Info ] ";
std::string five = " Fake: ";
std::string six = resolver->enemy_fake ? "TRUE." : "FALSE.";
std::string seven = " Valid Tick: ";
std::string eight = gay ? "TRUE." : "FALSE.";
std::string nine = " Delay Shot: ";
std::string ten = delayshot ? "TRUE." : "FALSE.";
std::string eleven = " Enemy Speed: [ ";
std::string twelve = std::to_string(s);
std::string thirteen = " ]";
std::string fourteen = " Enemy Health: [ ";
std::string fifteen = std::to_string(the_nignog->GetHealth());
std::string sixteen = " ]";
std::string newline = ".     \n";

//----------------------------------------------
std::string EVENT_3 = " [ Mirror Setting ] ";
std::string desync1 = " Desync: ";
std::string desync2 = resolver->has_desync ? "TRUE." : "FALSE.";
std::string slow1 = " Slow Walk: ";
std::string slow2 = sw ? "TRUE." : "FALSE.";
std::string r1 = " Primary Resolver: ";
std::string r2 = options::menu.aimbot.resolver.getindex() == 2 ? "TRUE" : "FALSE";
//----------------------------------------------
std::string EVENT_4 = " [ Mirror Resolver ] ";
std::string resolver_stage_text = " Enemy Stage: ";
//	std::string resolver_stage_index = debug_helpers::stage_to_string(a_c->resolver_stage);
std::string resolver_flag_text = " Enemy Flag: ";
//	std::string resolver_flag_index = debug_helpers::resolver_flag_to_string(a_c->resolver_flag[the_nignog->GetIndex()]);

std::string homo = "         ";

std::string uremam = EVENT_2 + one + two + three + four + nn + ffs + newline;
std::string ruined_is_gay = EVENT_1 + five + six + seven + eight + nine + ten + eleven + twelve + thirteen + fourteen + fifteen + sixteen + newline;
std::string no_muslim = EVENT_3 + desync1 + desync2 + slow1 + slow2 + r1 + r2 + newline;
//	std::string i_hate_myself = EVENT_4 + resolver_stage_text + resolver_stage_index + resolver_flag_text + resolver_flag_index + newline;
std::string killme = homo + newline;

interfaces::cvar->ConsoleColorPrintf(Color(250, 100, 250, 255), uremam.c_str());
interfaces::cvar->ConsoleColorPrintf(Color(250, 100, 250, 255), ruined_is_gay.c_str());
interfaces::cvar->ConsoleColorPrintf(Color(250, 100, 250, 255), no_muslim.c_str());
//	interfaces::cvar->ConsoleColorPrintf(Color(250, 100, 250, 255), i_hate_myself.c_str()); Doesn't work i guess
interfaces::cvar->ConsoleColorPrintf(Color(100, 100, 100, 100), killme.c_str());
}
*/

void CAimbot::faxzee_extrapolation(IClientEntity * pTarget, Vector AP)
{
	pTarget->GetPredicted(AP);

	bt_2->ShotBackTrackStoreFSN(pTarget);

	{
		Vector position = pTarget->GetAbsOriginlol();
		Vector extr_position = position;

		float old_simtime = CMBacktracking::Get().current_record[pTarget->GetIndex()].m_flSimulationTime;
		float simtime = pTarget->GetSimulationTime();

		cm_backtrack->ExtrapolatePosition(pTarget, extr_position, simtime, pTarget->getvelocity());

		AP -= position;
		AP += extr_position;
	}

	bt_2->ShotBackTrackBeforeAimbot(pTarget);

	bt_2->RestoreTemporaryRecord(pTarget);

	cm_backtrack->StartLagCompensation(pTarget);

	new_backtracking->RestoreTemporaryRecord(pTarget);
}


typedef void(__cdecl* MsgFn)(const char* msg, va_list);

void gamer_message(const char* msg, ...)
{
	if (msg == nullptr)
		return; //If no string was passed, or it was null then don't do anything
	static MsgFn fn = (MsgFn)GetProcAddress(GetModuleHandle("tier0.dll"), "Msg"); char buffer[989];
	va_list list;
	va_start(list, msg);
	vsprintf(buffer, msg, list);
	va_end(list);
	fn(buffer, list); //Calls the function, we got the address above.
}

inline int time_to_ticks(float time) {
	return static_cast< int >(time / interfaces::globals->interval_per_tick + 0.5f);
}

float CAimbot::interpolation_time() { // interpolation niggas

	static const auto                 cl_updaterate = interfaces::cvar->FindVar("cl_updaterate");
	static const auto              sv_minupdaterate = interfaces::cvar->FindVar("sv_minupdaterate");
	static const auto              sv_maxupdaterate = interfaces::cvar->FindVar("sv_maxupdaterate");
	static const auto               cl_interp_ratio = interfaces::cvar->FindVar("cl_interp_ratio");
	static const auto                     cl_interp = interfaces::cvar->FindVar("cl_interp");
	static const auto    sv_client_min_interp_ratio = interfaces::cvar->FindVar("sv_client_min_interp_ratio");
	static const auto    sv_client_max_interp_ratio = interfaces::cvar->FindVar("sv_client_max_interp_ratio");

	const auto update_rate = clamp(cl_updaterate->GetFloat(),
		sv_minupdaterate->GetFloat(),
		sv_maxupdaterate->GetFloat());

	const auto base_interp_ratio = (cl_interp_ratio->GetFloat() == 0.0f) ? 1.0f : cl_interp_ratio->GetFloat();

	const auto interp_ratio = clamp(base_interp_ratio,
		sv_client_min_interp_ratio->GetFloat(),
		sv_client_max_interp_ratio->GetFloat());

	const auto interp_latency = (interp_ratio / update_rate);

	return std::max<float>(cl_interp->GetFloat(), interp_latency);
}

void CAimbot::DoAimbot(CUserCmd *pCmd, bool &bSendPacket)
{
	bool vac_kick = options::menu.misc.OtherSafeMode.getindex() == 1;
	bool current_lagpred = options::menu.aimbot.lag_pred.getindex() > 1;
	IClientEntity* pLocal = interfaces::ent_list->get_client_entity(interfaces::engine->GetLocalPlayer());
	bool FindNewTarget = true;
	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());
	CMBacktracking gladbacktrack;
	if (!pLocal)
		return;

	if (pWeapon)
	{
		if ((!pWeapon->isZeus() && pWeapon->GetAmmoInClip() < 1) || pWeapon->IsKnife() || pWeapon->IsC4() || pWeapon->IsGrenade())
			return;
	}
	else
		return;

	if (IsLocked && TargetID > -0 && HitBox >= 0)
	{
		pTarget = interfaces::ent_list->get_client_entity(TargetID);
		if (pTarget && TargetMeetsRequirements(pTarget, pLocal))
		{
			HitBox = HitScan(pTarget, pLocal);
			if (HitBox >= 0)
			{
				Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
				Vector View; interfaces::engine->get_viewangles(View);
				float FoV = FovToPlayer(ViewOffset, View, pTarget, HitBox);

				if (FoV < vac_kick ? 39.f : options::menu.aimbot.AimbotFov.getvalue())
					FindNewTarget = false;
			}
		}
	}

	if (FindNewTarget)
	{
		Globals::Shots = 0;
		TargetID = 0;
		pTarget = nullptr;
		HitBox = -1;
		TargetID = get_target_fov(pLocal);

		if (TargetID >= 0)
		{
			pTarget = interfaces::ent_list->get_client_entity(TargetID);
		}

	}

	if (TargetID >= 0 && pTarget)
	{
		HitBox = HitScan(pTarget, pLocal);

		if (!CanOpenFire(pLocal))
			return;

		//	bool IsAtPeakOfJump = fabs(pLocal->GetVelocity().z) <= 5.0f;

		if (options::menu.aimbot.lag_pred.getindex() > 2)
			C_LagCompensation::instance().start_position_adjustment();

		Vector AP;
		AP = options::menu.aimbot.Multienable.getstate() ? GetHitboxPosition(pTarget, HitBox) : hitbox_location(pTarget, HitBox);

		shot_this_tick = false;

		switch (options::menu.misc.QuickStop.getindex())
		{
		case 1:
		{
			if (pLocal->GetFlags() & FL_ONGROUND)
			{
				ClampMovement(pCmd, c_misc->get_gun(pWeapon));
			}
		}
		break;

		case 2:
		{
		
				c_misc->MinimalWalk(pCmd, c_misc->get_gun(pWeapon));
			
		}
		break;
		}

		switch (options::menu.aimbot.lag_pred.getindex())
		{
		case 1: pTarget->GetPredicted(AP);
			break;
		case 2:
			faxzee_extrapolation(pTarget, AP);
			break;
		}
		//	Globals::missedshots[pTarget->GetIndex()] = Globals::fired[pTarget->GetIndex()] - Globals::hit[pTarget->GetIndex()];

		float hc = hitchance();
		if (game_utils::IsScopedWeapon(pWeapon) && !pWeapon->IsScoped() && options::menu.aimbot.AccuracyAutoScope.getstate())
		{
			pCmd->buttons |= IN_ATTACK2;
		}

		int tickdiff;
		tickdiff = TIME_TO_TICKS(interfaces::engine->GetNetChannelInfo()->GetAvgLatency(FLOW_INCOMING) + interfaces::engine->GetNetChannelInfo()->GetAvgLatency(FLOW_OUTGOING));

		auto simtime = pTarget->get_simulation_time();
		simtime += interpolation_time();

		if (options::menu.aimbot.lag_pred.getindex() > 2)
			C_LagCompensation::instance().finish_position_adjustment();

		if (pWeapon->isZeus27() && c_misc->do_zeus && (hc >= options::menu.aimbot.AccuracyHitchance.getvalue() * 1.5))
		{
			if (AimAtPoint(pLocal, AP, pCmd, bSendPacket))
			{
				cbacktracking::Get().ShotBackTrackAimbotStart(pTarget);
				cbacktracking::Get().RestoreTemporaryRecord(pTarget);
				cbacktracking::Get().ShotBackTrackedTick(pTarget);

				for (int t = 0; t < (bt_2->ticks); ++t)
				{
					sim_time_delay(pTarget); // make sure simtime is correct to help in hitting

					if (!game_utils::is_visible(pLocal, pTarget, 2))
						continue;

					if (!shot_refined) // no u
						continue;

					pCmd->buttons |= IN_ATTACK; // bang

					if (backtracking->IsTickValid(pTarget->GetSimulationTime() + backtracking->GetLerpTime())) // is it a valid tick?
						pCmd->tick_count = TIME_TO_TICKS(pTarget->GetSimulationTime() + backtracking->GetLerpTime());

				}
			}
			return;
		}

		if ((hc >= options::menu.aimbot.AccuracyHitchance.getvalue() * 1.5))
		{
			if (options::menu.misc.QuickCrouch.getstate())
				pCmd->buttons |= IN_DUCK;

			if (pLocal->get_animation_state()->m_fDuckAmount > 0.99 && !(GetAsyncKeyState(options::menu.misc.fake_crouch_key.GetKey())) && !interfaces::m_iInputSys->IsButtonDown(KEY_LCONTROL))
				return;

			if (AimAtPoint(pLocal, AP, pCmd, bSendPacket))
			{
				if (options::menu.aimbot.AimbotAutoFire.getstate() && !(pCmd->buttons & IN_ATTACK))
				{

					//				if ((GetAsyncKeyState(options::menu.misc.fake_crouch_key.GetKey())) && pLocal->get_animation_state()->m_fDuckAmount > 0.3)
					//					return;

					if (options::menu.aimbot.delay_shot.getindex() != 0)
					{
						delay_shot(pTarget, pCmd);
						switch (can_shoot)
						{
						case true:
						{
							switch (options::menu.aimbot.lag_pred.getindex())
							{
							case 1: // old mirror vibes
							{

								cbacktracking::Get().ShotBackTrackAimbotStart(pTarget);
								cbacktracking::Get().RestoreTemporaryRecord(pTarget);
								cbacktracking::Get().ShotBackTrackedTick(pTarget);

								c_fakelag->shot = true;

								pCmd->buttons |= IN_ATTACK;
								if (backtracking->IsTickValid(pTarget->GetSimulationTime() + backtracking->GetLerpTime()))
									pCmd->tick_count = TIME_TO_TICKS(pTarget->GetSimulationTime()) + TIME_TO_TICKS(backtracking->GetLerpTime()) + tickdiff;

								c_fakelag->shot = false;
								shot_this_tick = true;
							}
							break;

							case 2:
							{
								//		if (options::menu.aimbot.delay_shot.getindex() > 2)
								//			new_backtracking->ShotBackTrackAimbotStart(pTarget);

								cbacktracking::Get().ShotBackTrackAimbotStart(pTarget);
								cbacktracking::Get().RestoreTemporaryRecord(pTarget);
								cbacktracking::Get().ShotBackTrackedTick(pTarget);

								c_fakelag->shot = true;
								Globals::fired[pTarget->GetIndex()]++;

								for (int t = 0; t < (bt_2->ticks); ++t)
								{
							//		if (bt_2->ticks < 1) // let's go for backtrack ticks
							//			continue;

									sim_time_delay(pTarget); // make sure simtime is correct to help in hitting

									if (!shot_refined) // no u
										continue;

									if (backtracking->IsTickValid(pTarget->GetSimulationTime() + backtracking->GetLerpTime())) // is it a valid tick?
									{
										//	pCmd->tick_count = TIME_TO_TICKS(simtime); 
										pCmd->tick_count = TIME_TO_TICKS(pTarget->GetSimulationTime() + backtracking->GetLerpTime());
									}

									pCmd->buttons |= IN_ATTACK; // bang
								
								}

								c_fakelag->shot = false;
								shot_this_tick = true;
							}
							break;

							case 3: // in case you can't tell, the lag comp above is limited to this mode only
							{
								//		if (options::menu.aimbot.delay_shot.getindex() > 2)
								//			new_backtracking->ShotBackTrackAimbotStart(pTarget);

								cbacktracking::Get().ShotBackTrackAimbotStart(pTarget);
								cbacktracking::Get().RestoreTemporaryRecord(pTarget);
								cbacktracking::Get().ShotBackTrackedTick(pTarget);

								c_fakelag->shot = true;
								Globals::fired[pTarget->GetIndex()]++;

								for (int t = 0; t < (bt_2->ticks); ++t)
								{
									//		if (bt_2->ticks < 1) // let's go for backtrack ticks
									//			continue;

									sim_time_delay(pTarget); // make sure simtime is correct to help in hitting

									if (!shot_refined) // no u
										continue;

									if (backtracking->IsTickValid(pTarget->GetSimulationTime() + backtracking->GetLerpTime())) // is it a valid tick?
									{
										//	pCmd->tick_count = TIME_TO_TICKS(simtime); 
										pCmd->tick_count = TIME_TO_TICKS(pTarget->GetSimulationTime() + backtracking->GetLerpTime());
									}

									pCmd->buttons |= IN_ATTACK; // bang

								}

								c_fakelag->shot = false;
								shot_this_tick = true;
							}
							break;
							}
						}
						break;
						}

					}
					else
					{
						c_fakelag->shot = true;

						if (options::menu.misc.QuickCrouch.getstate())
							pCmd->buttons |= IN_DUCK;

						pCmd->buttons |= IN_ATTACK;
						Globals::fired[pTarget->GetIndex()]++;

						c_fakelag->shot = false;
						shot_this_tick = true;
					}

					was_firing_test = true;

					if (!(pCmd->buttons |= IN_ATTACK))
					{
						shot_this_tick = false;
					}

				}
				else if (pCmd->buttons & IN_ATTACK || (pCmd->buttons & IN_ATTACK2 && !game_utils::AutoSniper(pWeapon)))
				{

					Globals::fired[pTarget->GetIndex()]++;
					c_fakelag->shot = false;
					was_firing_test = false;

					return;
				}

				if (*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() != 64)
				{
					static bool WasFiring = false;
					if (*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() == 31)
					{
						if (pCmd->buttons & IN_ATTACK)
						{
							if (WasFiring)
							{
								pCmd->buttons &= ~IN_ATTACK;
								//	was_firing = true;
							}
						}
						//		else
						//			was_firing = false;

						WasFiring = pCmd->buttons & IN_ATTACK ? true : false;
					}
				}
			}
		}

	}

	if (IsAbleToShoot(pLocal) && pCmd->buttons & IN_ATTACK) {
		Globals::Shots += 1;
	}
	//	missed_shot_log(pCmd, pWeapon);
}


float VectorDistance(const Vector& v1, const Vector& v2)
{
	return FastSqrt(pow(v1.x - v2.x, 2) + pow(v1.y - v2.y, 2) + pow(v1.z - v2.z, 2));
}

bool CAimbot::TargetMeetsRequirements(IClientEntity* pEntity, IClientEntity* local)
{
	//	auto local = interfaces::ent_list->get_client_entity(interfaces::engine->GetLocalPlayer());
//	ClientClass *pClientClass = pEntity->GetClientClass();
	if (pEntity->isValidPlayer())
	{
		player_info_t pinfo;
		if (pEntity->cs_player() && interfaces::engine->GetPlayerInfo(pEntity->GetIndex(), &pinfo))
		{
			C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(local->GetActiveWeaponHandle());

			float Distance = VectorDistance(local->GetEyePosition(), pEntity->GetEyePosition());

			if (pWeapon && pWeapon->GetCSWpnData()->range < Distance)
				return false;

			if (!pEntity->is_dormant())
			{
				// Team Check
				if (options::menu.misc.OtherSafeMode.getindex() != 3 ? pEntity->team() != local->team() : pEntity->GetIndex() != local->GetIndex())
				{
					// Spawn And Dormant Check
					if (!pEntity->has_gungame_immunity())
					{
						if (!(pEntity->GetFlags() & FL_FROZEN)) // ice age niggas
						{
							return true;
						}
					}

				}
			}
			
		}
	}
	return false;
}

float CAimbot::FovToPlayer(Vector ViewOffSet, Vector View, IClientEntity* pEntity, int aHitBox)
{

	CONST FLOAT MaxDegrees = 180.0f;

	Vector Angles = View;

	Vector Origin = ViewOffSet;

	Vector Delta(0, 0, 0);

	Vector Forward(0, 0, 0);

	AngleVectors(Angles, &Forward);

	Vector AimPos = GetHitboxPosition(pEntity, aHitBox);

	VectorSubtract(AimPos, Origin, Delta);

	Normalize(Delta, Delta);

	FLOAT DotProduct = Forward.Dot(Delta);

	return (acos(DotProduct) * (MaxDegrees / PI));
}
int CAimbot::get_target_fov(IClientEntity* pLocal)
{
	int target = -1;
	float min_fov = 180.f;

	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; interfaces::engine->get_viewangles(View);

	for (int i = 0; i < 65; i++)
	{
		IClientEntity *pEntity = interfaces::ent_list->get_client_entity(i);
		if (TargetMeetsRequirements(pEntity, pLocal))
		{
			if (pEntity->GetOrigin() == Vector(0, 0, 0))
				continue;

			int NewHitBox = HitScan(pEntity, pLocal);
			if (NewHitBox >= 0)
			{
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (fov <= min_fov && fov <= 180.f)
				{
					min_fov = fov;
					target = i;
				}
			}
		}
	}

	return target;
}
float GetFov(const QAngle& viewAngle, const QAngle& aimAngle)
{
	Vector ang, aim;
	AngleVectors(viewAngle, &aim);
	AngleVectors(aimAngle, &ang);
	return RAD2DEG(acos(aim.Dot(ang) / aim.LengthSqr()));
}
bool CAimbot::should_baim(IClientEntity* pEntity)
{
	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(pEntity->GetActiveWeaponHandle());

	if (!pWeapon)
		return false;

	float health = options::menu.aimbot.BaimIfUnderXHealth.getvalue();
	int miss[65] = { Globals::missedshots[pEntity->GetIndex()] };

	bool nn[65] = { miss[pEntity->GetIndex()] > 2 };

	if ((GetAsyncKeyState(options::menu.aimbot.bigbaim.GetKey()) ||
		(options::menu.aimbot.baim_fakewalk.getstate() && (enemy_is_slow_walking(pEntity)))
		|| (options::menu.aimbot.baim_fake.getstate() && nn[pEntity->GetIndex()])
		|| (options::menu.aimbot.baim_inair.getstate() && !(pEntity->GetFlags() & FL_ONGROUND))
		|| pEntity->GetHealth() <= health)
		|| game_utils::IsZeus(pWeapon))
	{
		return true;
	}
	else
		return false;

	return false;
}


void CAimbot::missed_shot_log(CUserCmd * pcmd, C_BaseCombatWeapon* pWeapon)
{

	if (!pTarget)
		return;

	static int missedshots[65];
	missedshots[pTarget->GetIndex()] = Globals::missedshots[pTarget->GetIndex()];

	if (CanOpenFire(hackManager.pLocal()))
		return;

	bool reset = false;
	valid_hitchance = hitchance() <= options::menu.aimbot.AccuracyHitchance.getvalue() * 1.5;

	if ( (missedshots[pTarget->GetIndex()] > 0 && Globals::fired[pTarget->GetIndex()] != missedshots[pTarget->GetIndex()] && pWeapon->GetInaccuracy() > 0 && pcmd->buttons & IN_ATTACK) || (Globals::fired[pTarget->GetIndex()] > missedshots[pTarget->GetIndex()] && !reset) )
	{
		
		interfaces::cvar->ConsoleColorPrintf(Color(160, 5, 240, 255), "Mirror: ");

		std::string one = "missed due to innacuracy";
		std::string newline = ".     \n";
		std::string uremam = one + newline;

		gamer_message(uremam.c_str());

		Globals::fired[pTarget->GetIndex()] = 0;
		Globals::hit[pTarget->GetIndex()] = 0;
		Globals::missedshots[pTarget->GetIndex()] = 0.f;
		missedshots[pTarget->GetIndex()] = 0;

		reset = true;
	}

	IGameEvent* event;

	if (event == nullptr)
		return;
	int user = event->GetInt("userid");

	if ((Globals::fired[pTarget->GetIndex()] != Globals::missedshots[pTarget->GetIndex()] || ext->current_flag[interfaces::engine->GetPlayerForUserID(user)] == correction_flags::DESYNC) && pTarget->getvelocity().Length2D() < 120 )
	{
		interfaces::cvar->ConsoleColorPrintf(Color(160, 5, 240, 255), "Mirror: ");

		std::string one = "missed due to bad resolve";
		std::string newline = ".     \n";
		std::string uremam = one + newline;
		gamer_message(uremam.c_str());
	}
}


bool CAimbot::enemy_is_slow_walking(IClientEntity * entity)
{
	C_BaseCombatWeapon* weapon = entity->GetWeapon2();
	if (!weapon)
		return false;

	float speed = entity->getvelocity().Length2D();

	if (speed < 50.f && speed >= 25.f) // if it's more or less the same.
	{
		return true;
	}
	else
		return false;

}

/*
int CAimbot::automatic_hitscan(IClientEntity * entity)
{
	int hp = entity->GetHealth();
	int speed = entity->GetVelocity().Length();

	if (entity == nullptr)
		return 0;

#pragma region " 1 = head, pelvis | 2 = head, stomach, pelvis | 3 - full scan | 4- body only | 5 - head, lower body, legs "

	if (speed >= 210)
	{
		if (hp >= 70)
		{
			return 1;
		}

		if (hp < 70 && hp >= 50)
		{
			return 2;
		}

		if (hp < 50)
		{
			return 3;
		}
	}

	if (speed < 210 && speed >= 150)
	{
		if (hp >= 50)
		{
			return 2;
		}

		if (hp < 50)
		{
			return 3;
		}
	}

	if (speed < 150)
	{
		if (hp >= 70)
		{
			return 5;
		}

		if (hp < 70 && hp > 50)
		{
			return 3;
		}

		if (hp <= 50)
		{
			return 4;
		}
	}
}
*/

std::vector<int> CAimbot::head_hitscan()
{
	std::vector<int> hitbox;
	hitbox.push_back((int)csgo_hitboxes::head);
	//	hitbox.push_back((int)csgo_hitboxes::neck);

	return hitbox;
}


/*
std::vector<int> CAimbot::upperbody_hitscan()
{
std::vector<int> hitbox;
hitbox.push_back((int)csgo_hitboxes::upper_chest);
hitbox.push_back((int)csgo_hitboxes::thorax);

return hitbox;
}
*/
std::vector<int> CAimbot::lowerbody_hitscan()
{
	std::vector<int> hitbox;
	hitbox.push_back((int)csgo_hitboxes::lower_chest);
	hitbox.push_back((int)csgo_hitboxes::pelvis);
	hitbox.push_back((int)csgo_hitboxes::stomach);
	hitbox.push_back((int)csgo_hitboxes::left_thigh);
	hitbox.push_back((int)csgo_hitboxes::right_thigh);
	hitbox.push_back((int)csgo_hitboxes::upper_chest);
	return hitbox;
}
/*
std::vector<int> CAimbot::arms_hitscan()
{
std::vector<int> hitbox;
hitbox.push_back((int)csgo_hitboxes::right_upper_arm);
hitbox.push_back((int)csgo_hitboxes::left_upper_arm);
hitbox.push_back((int)csgo_hitboxes::right_lower_arm);
hitbox.push_back((int)csgo_hitboxes::left_lower_arm);
hitbox.push_back((int)csgo_hitboxes::right_hand);
hitbox.push_back((int)csgo_hitboxes::left_hand);

return hitbox;
}

std::vector<int> CAimbot::legs_hitscan()
{
std::vector<int> hitbox;
hitbox.push_back((int)csgo_hitboxes::left_calf);
hitbox.push_back((int)csgo_hitboxes::left_foot);
hitbox.push_back((int)csgo_hitboxes::right_calf);
hitbox.push_back((int)csgo_hitboxes::right_foot);

return hitbox;
}
*/

std::vector<int> CAimbot::awp_minimal_hitscan()
{
	std::vector<int> scan_hitboxes;
	scan_hitboxes.push_back((int)csgo_hitboxes::stomach);
	scan_hitboxes.push_back((int)csgo_hitboxes::lower_chest);
	scan_hitboxes.push_back((int)csgo_hitboxes::pelvis);
	scan_hitboxes.push_back((int)csgo_hitboxes::right_foot);
	scan_hitboxes.push_back((int)csgo_hitboxes::left_foot);

	return scan_hitboxes;
}

std::vector<int> CAimbot::minimal_hitscan()
{
	std::vector<int> scan_hitboxes;
	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	scan_hitboxes.push_back((int)csgo_hitboxes::head);

	scan_hitboxes.push_back((int)csgo_hitboxes::upper_chest);
	scan_hitboxes.push_back((int)csgo_hitboxes::pelvis);

	scan_hitboxes.push_back((int)csgo_hitboxes::right_foot);
	scan_hitboxes.push_back((int)csgo_hitboxes::left_foot);

	return scan_hitboxes;
}

std::vector<int> CAimbot::essential_hitscan()
{
	std::vector<int> scan_hitboxes;
	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	scan_hitboxes.push_back((int)csgo_hitboxes::upper_chest);
	scan_hitboxes.push_back((int)csgo_hitboxes::lower_chest);

	if (!options::menu.aimbot.ignore_limbs.getstate())
	{
		scan_hitboxes.push_back((int)csgo_hitboxes::left_upper_arm);
		scan_hitboxes.push_back((int)csgo_hitboxes::right_upper_arm);

		scan_hitboxes.push_back((int)csgo_hitboxes::right_foot);
		scan_hitboxes.push_back((int)csgo_hitboxes::left_foot);
	}

	scan_hitboxes.push_back((int)csgo_hitboxes::pelvis);
	scan_hitboxes.push_back((int)csgo_hitboxes::left_thigh);
	scan_hitboxes.push_back((int)csgo_hitboxes::right_thigh);

	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	return scan_hitboxes;
}

std::vector<int> CAimbot::maximal_hitscan()
{
	std::vector<int> scan_hitboxes;
	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	scan_hitboxes.push_back((int)csgo_hitboxes::upper_chest);
	scan_hitboxes.push_back((int)csgo_hitboxes::lower_chest);


	if (!options::menu.aimbot.ignore_limbs.getstate())
	{
		scan_hitboxes.push_back((int)csgo_hitboxes::left_upper_arm);
		scan_hitboxes.push_back((int)csgo_hitboxes::right_upper_arm);
		scan_hitboxes.push_back((int)csgo_hitboxes::left_lower_arm);
		scan_hitboxes.push_back((int)csgo_hitboxes::right_lower_arm);
		scan_hitboxes.push_back((int)csgo_hitboxes::right_foot);
		scan_hitboxes.push_back((int)csgo_hitboxes::left_foot);
	
	}

	scan_hitboxes.push_back((int)csgo_hitboxes::stomach);
	scan_hitboxes.push_back((int)csgo_hitboxes::pelvis);
	scan_hitboxes.push_back((int)csgo_hitboxes::left_thigh);
	scan_hitboxes.push_back((int)csgo_hitboxes::right_thigh);
	scan_hitboxes.push_back((int)csgo_hitboxes::head);

	return scan_hitboxes;
}

std::vector<int> CAimbot::head_only_hitscan()
{
	std::vector<int> scan_hitboxes;
	scan_hitboxes.push_back((int)csgo_hitboxes::head);
	return scan_hitboxes;

}

int CAimbot::HitScan(IClientEntity* pEntity, IClientEntity* pLocal)
{

	float health = options::menu.aimbot.BaimIfUnderXHealth.getvalue();

	std::vector<int> scan_hitboxes;
	//	std::vector<dropdownboxitem> auto_list = options::menu.aimbot.target_auto.items;
	//	std::vector<dropdownboxitem> scout_list = options::menu.aimbot.target_scout.items;
	//	std::vector<dropdownboxitem> awp_list = options::menu.aimbot.target_awp.items;
	//	std::vector<dropdownboxitem> pistol_list = options::menu.aimbot.target_pistol.items;
	//	std::vector<dropdownboxitem> smg_list = options::menu.aimbot.target_smg.items;
	//	std::vector<dropdownboxitem> otr_list = options::menu.aimbot.target_otr.items;

	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	bool do_head = options::menu.aimbot.head_walking.getstate() && pEntity->getvelocity().Length2D() > 29.f  
		&& game_utils::is_visible(pLocal, pEntity, 0) && !(GetAsyncKeyState(options::menu.aimbot.bigbaim.GetKey()));
	if (pWeapon != nullptr)
	{
		switch (should_baim(pEntity))
		{
			case true:
			{
				scan_hitboxes = lowerbody_hitscan();
			}
			break;

			case false:
			{
				switch (do_head)
				{
					case true:
					{
						scan_hitboxes = head_only_hitscan();
					}
					break;

					case false:
					{
						if (pWeapon->isAuto())
						{

							switch (options::menu.aimbot.target_auto2.getindex())
							{
							case 1:
								scan_hitboxes = minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}

						}
						if (pWeapon->is_scout())
						{
							switch (options::menu.aimbot.target_scout2.getindex())
							{
							case 1:
								scan_hitboxes = minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}

						}

						if (pWeapon->is_awp())
						{
							switch (options::menu.aimbot.target_awp2.getindex())
							{
							case 1:
								scan_hitboxes = awp_minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}

						}

						if (pWeapon->isPistol()) // head
						{

							switch (options::menu.aimbot.target_pistol2.getindex())
							{
							case 1:
								scan_hitboxes = minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}

						}

						if (game_utils::IsMP(pWeapon))
						{

							switch (options::menu.aimbot.target_smg2.getindex())
							{
							case 1:
								scan_hitboxes = minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}

						}

						if (game_utils::IsRifle(pWeapon) || game_utils::IsShotgun(pWeapon) || game_utils::IsMachinegun(pWeapon))
						{

							switch (options::menu.aimbot.target_otr2.getindex())
							{
							case 1:
								scan_hitboxes = minimal_hitscan();
								break;
							case 2:
								scan_hitboxes = essential_hitscan();
								break;
							case 3:
								scan_hitboxes = maximal_hitscan();
								break;
							}
						}
					}
					break;
				}
			}
			break;
		}	

		for (auto HitBoxID : scan_hitboxes)
		{
			Vector Point, lol;
			Point = GetHitboxPosition(pEntity, HitBoxID);

			float dmg = 0.f;

			if (backup_awall->can_hit(Point, &dmg))
			{
				return HitBoxID;
			}

		}
		return -1;
	}
}

void CAimbot::DoNoRecoil(CUserCmd *pCmd, bool &packet)
{
	Vector AimPunch = hackManager.pLocal()->localPlayerExclusive()->GetAimPunchAngle();
	if (AimPunch.Length2D() > 0 && AimPunch.Length2D() < 150)
	{
		pCmd->viewangles -= AimPunch * 2.00;
		game_utils::NormaliseViewAngle(pCmd->viewangles);
	}
	
}

void CAimbot::aimAtPlayer(CUserCmd *pCmd, IClientEntity* pLocal)
{
	//	IClientEntity* pLocal = hackManager.pLocal();

	C_BaseCombatWeapon* pWeapon = (C_BaseCombatWeapon*)interfaces::ent_list->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());

	if (!pLocal || !pWeapon)
		return;

	Vector eye_position = pLocal->GetEyePosition();

	float best_dist = pWeapon->GetCSWpnData()->range;

	IClientEntity* target = nullptr;

	for (int i = 0; i <= 65; i++)
	{
		IClientEntity *pEntity = interfaces::ent_list->get_client_entity(i);
		if (TargetMeetsRequirements(pEntity, pLocal))
		{
			if (TargetID != -1)
				target = interfaces::ent_list->get_client_entity(TargetID);
			else
				target = pEntity;

			Vector target_position = target->GetEyePosition();
			Vector CurPos = target->GetEyePosition() + target->GetAbsOrigin();

			float temp_dist = eye_position.DistTo(target_position);
			QAngle angle = QAngle(0, 0, 0);
			float lowest = 99999999.f;
			if (CurPos.DistToSqr(eye_position) < lowest)
			{
				lowest = CurPos.DistTo(eye_position);
				CalcAngle(eye_position, target_position, angle);
			}
		}
	}
}

bool CAimbot::AimAtPoint(IClientEntity* pLocal, Vector point, CUserCmd *pCmd, bool &bSendPacket)
{
	bool ReturnValue = false;
	if (point.Length() == 0) return ReturnValue;
	Vector angles;
	Vector src = pLocal->GetOrigin() + pLocal->GetViewOffset();
	CalcAngle(src, point, angles);
	game_utils::NormaliseViewAngle(angles);
	if (angles[0] != angles[0] || angles[1] != angles[1])
	{
		return ReturnValue;
	}
	IsLocked = true;
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	if (!IsAimStepping)
		LastAimstepAngle = LastAngle;
	float fovLeft = FovToPlayer(ViewOffset, LastAimstepAngle, interfaces::ent_list->get_client_entity(TargetID), 0);
	Vector AddAngs = angles - LastAimstepAngle;
	if (fovLeft > 29.0f && options::menu.misc.OtherSafeMode.getindex() == 1)
	{
		Vector AddAngs = angles - LastAimstepAngle;
		Normalize(AddAngs, AddAngs);
		AddAngs *= 29.0f;
		LastAimstepAngle += AddAngs;
		game_utils::NormaliseViewAngle(LastAimstepAngle);
		angles = LastAimstepAngle;
	}

	else
	{
		ReturnValue = true;
	}
	//	if (Options::Menu.aimbot_tab.AimbotSilentAim.GetState())
	//	{
	pCmd->viewangles = angles;
	//	}
	//	if (!Options::Menu.aimbot_tab.AimbotSilentAim.GetState())
	//	{
	//		Interfaces::Engine->SetViewAngles(angles);
	//	}


	return ReturnValue;
}
