#include "globalshhh.h"

Globalsh globalsh;