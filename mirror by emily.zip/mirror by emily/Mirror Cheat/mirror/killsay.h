#pragma once
#include "Hacks.h"

std::vector<std::string> killmsg =
{
	"that's a yikes",
	"couple thousand on my wrist",
	"uuh i hope you didn't pay for that",
	"muslims getting yeeted on",
	"uno!",
	"sorry! couldn't hear you over the sound of that 1",
	"that made me break my f12 key",
	"hey how does the death screen look? I haven't seen it in a while",
	"p2c fags lol",
	"you should type 'quit' in console. Trust me ",
	"looks pasted",
	" *DEAD* ",
	"paypal is waiting for ya bud",
	"i get the feeling you were dropped on your head as a kid, repeatedly, for 3 hours. Just a hunch",
	"you're the sort of person to get 3rd place in a 1v1",
	"i would just like to point out Lucky (the youtuber) is gay",
	"gOd i WiSh I hAd MoNeY bOt",
	"spin on my dick like a beyblade, uh"
};

std::vector<std::string> deathmsg =
{
	"fucking muslims",
	"do you have a fucking toe fettish?",
	"yea nice 1way",
	"fucks sake, my dog started barking",
	"i had fps drops",
	"you teleported",
	"fucking teleported me back lol",
	"wasn't a headshot lol you manipulated the killfeed hh",
	"fucking apes",
	"are you trying to be xane or are you legitimately a gorilla?",
	"fucking ooga booga monkey kys",
	"nice server side, making expose vid rn",
	"yea pastes can hit pelvis too",
	"nice max fakelag pussy",
	"are you using penguware or some shit? slow walk baim only pussy",
	"you are a gigant slow walking vagina"
};